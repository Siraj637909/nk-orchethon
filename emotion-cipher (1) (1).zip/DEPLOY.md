# Deployment Guide for Emotion Cipher

## Quick Start (Local)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
python app.py

# 3. Open browser
http://localhost:5000
```

## Deploy to FREE Services

### Option 1: Render.com (Easiest)

1. Create GitHub repo with these files:
   - app.py
   - emotion_cipher.py
   - templates/index.html
   - requirements.txt
   - Procfile

2. Create Procfile:
```
web: python app.py
```

3. Go to render.com
4. Connect your GitHub
5. Create new Web Service
6. Deploy!

### Option 2: Railway

1. Push to GitHub
2. Go to railway.app
3. New Project → Deploy from GitHub
4. Done!

### Option 3: PythonAnywhere

1. Go to pythonanywhere.com
2. Create account (free)
3. Upload files
4. Open bash tab
5. pip install -r requirements.txt
6. Web tab → Add new web app
7. Configure WSGI file

## Files Structure

```
emotion-cipher/
├── app.py              # Flask app
├── emotion_cipher.py   # Core logic
├── templates/
│   └── index.html      # Frontend
├── requirements.txt    # Dependencies
├── Procfile           # For deployment
└── README.md          # This file
```

## Video Demo

Record your screen using Loom or OBS:
1. Show the web app
2. Type a message with emotion
3. Click Encrypt
4. Show the encrypted output
5. Click Decrypt
6. Show original + emotion restored

Add video link to README.md

---

Good luck with the hackathon! 🎉
