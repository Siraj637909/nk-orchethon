"""
Emotion Cipher - Flask Web Application
"""
from flask import Flask, render_template, request, jsonify
from emotion_cipher import EmotionCipher
import base64
import hashlib

app = Flask(__name__)

# Store ciphers per session (in production, use proper session management)
session_ciphers = {}

def get_cipher(key=None):
    """Get or create cipher instance"""
    if key:
        try:
            key_bytes = base64.urlsafe_b64decode(key.encode())
            return EmotionCipher(key_bytes)
        except:
            return EmotionCipher(key.encode())
    return EmotionCipher()

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/encrypt', methods=['POST'])
def encrypt():
    """Encrypt text with emotion detection"""
    data = request.get_json()
    text = data.get('text', '').strip()
    custom_key = data.get('key', None)
    
    if not text:
        return jsonify({'error': 'Please enter some text'})
    
    cipher = get_cipher(custom_key)
    result = cipher.encrypt(text)
    
    return jsonify({
        'encrypted': result['encrypted'],
        'emotion': result['emotion'],
        'key': result['key']
    })

@app.route('/decrypt', methods=['POST'])
def decrypt():
    """Decrypt text and extract emotion"""
    data = request.get_json()
    encrypted_text = data.get('encrypted', '').strip()
    key = data.get('key', '').strip()
    
    if not encrypted_text:
        return jsonify({'error': 'Please enter encrypted text'})
    
    if not key:
        return jsonify({'error': 'Please enter the decryption key'})
    
    cipher = get_cipher(key)
    result = cipher.decrypt(encrypted_text)
    
    if 'error' in result:
        return jsonify({'error': result['error']})
    
    return jsonify({
        'original': result['original'],
        'emotion': result['emotion']
    })

@app.route('/detect-emotion', methods=['POST'])
def detect_emotion():
    """Just detect emotion without encryption"""
    data = request.get_json()
    text = data.get('text', '').strip()
    
    if not text:
        return jsonify({'error': 'Please enter some text'})
    
    cipher = EmotionCipher()
    emotion = cipher.detect_emotion(text)
    
    return jsonify({'emotion': emotion})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
