# 🔐🎭 Emotion Cipher

### Privacy Meets Empathy - Words Protected, Feelings Detectable

![Hackathon](https://img.shields.io/badge/UnsaidTalks-Hackathon-7B2CBF)
![License](https://img.shields.io/badge/License-MIT-00F5D4)
![Version](https://img.shields.io/badge/Version-1.0-FF6B6B)

## 🎯 What Is Emotion Cipher?

Emotion Cipher is an innovative encryption system that protects text messages while preserving their emotional signature. This allows AI systems to detect emotions even from encrypted data, bridging the gap between privacy and emotional intelligence.

## ✨ Key Features

| Feature | Description |
|---------|-------------|
| 🔐 **AES-256 Encryption** | Military-grade encryption for ultimate security |
| 🧠 **AI Emotion Detection** | Detects Joy, Sadness, Anger, Fear, Anxiety, Excitement, Hope, Gratitude, Surprise |
| ⚡ **Client-Side Processing** | Your data never leaves your browser - 100% private |
| 🎨 **Modern UI** | Beautiful dark theme with smooth animations |

## 🚀 Live Demo

**🔗 [emotion-cipher.vercel.app](https://emotion-cipher.vercel.app)** *(Coming Soon)*

## 🏆 Hackathon Criteria

| Criteria | Our Approach |
|----------|---------------|
| **Impact (20%)** | Enables privacy-preserving emotion AI for mental health, customer service, security |
| **Innovation (20%)** | Novel concept - first system that keeps emotions readable while text is encrypted |
| **Technical Execution (20%)** | AES-256 encryption + NLP emotion analysis + modern web stack |
| **User Experience (25%)** | Clean, intuitive interface with real-time feedback |
| **Presentation (15%)** | [Demo Video Link] |

## 💡 Use Cases

1. **Mental Health Apps** - Analyze emotions while keeping messages private
2. **Customer Support** - Detect sentiment without reading actual messages
3. **Security** - Flag concerning emotional patterns without surveillance
4. **Healthcare** - Monitor patient emotional well-being while maintaining HIPAA compliance

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Encryption**: AES-256, Base64 encoding
- **Emotion Detection**: Natural Language Processing (NLP)
- **Deployment**: Vercel, Netlify, GitHub Pages

## 📱 How It Works

### Encryption Process
```
User Input → Emotion Detection → AES-256 Encryption → Encrypted Output + Emotion Signature
```

### Decryption Process
```
Encrypted Input → Extract Emotion → Decrypt → Original Message + Emotion
```

## 🎬 Demo Video

[Watch Demo Video](https://loom.com) *(Record with Loom and add link)*

## 📦 Installation

### Option 1: Run Locally
```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/emotion-cipher.git
cd emotion-cipher

# Open in browser
# Just open index.html in any browser!
```

### Option 2: Deploy to GitHub Pages
1. Go to Settings → Pages
2. Select "main" branch
3. Save → Your site is live!

### Option 3: Deploy to Vercel
```bash
npm i -g vercel
vercel
```

## 📂 Project Structure

```
emotion-cipher/
├── index.html          # Main application (works standalone!)
├── README.md           # This file
├── LICENSE            # MIT License
└── docs/
    └── images/        # Screenshots
```

## 🎯 Example

### Input
```
"I'm so excited about this opportunity but nervous about the interview!"
```

### Encrypted Output
```
Encrypted: VGhpcyBpcyBhbiBlbmNyeXB0ZWQgbWVzc2FnZS4uLg==
Emotion: Joy + Anxiety
```

### Decrypted
```
Original: "I'm so excited about this opportunity but nervous about the interview!"
Emotion: Joy + Anxiety ✓
```

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

Distributed under the MIT License.

## 👤 Author

- **Your Name** - [your-email@example.com](mailto:your-email@example.com)
- **GitHub**: [github.com/yourusername](https://github.com/yourusername)

## 🙏 Acknowledgments

- [UnsaidTalks](https://unsaidtalks.com) for organizing this hackathon
- All participants and judges

---

<p align="center">
  <strong>🏆 Built for UnsaidTalks Emotion-Aware Encryption Hackathon 🏆</strong>
</p>
