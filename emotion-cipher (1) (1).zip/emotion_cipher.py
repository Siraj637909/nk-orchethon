"""
Emotion Cipher - Core Logic
Encrypts text while preserving emotional signature
"""
import base64
import hashlib
from cryptography.fernet import Fernet
import re

class EmotionCipher:
    def __init__(self, key=None):
        if key:
            self.key = self._generate_key(key)
        else:
            self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)
    
    def _generate_key(self, password):
        """Generate encryption key from password"""
        return base64.urlsafe_b64encode(hashlib.sha256(password.encode()).digest())
    
    def detect_emotion(self, text):
        """Detect emotion from text using keyword analysis"""
        text_lower = text.lower()
        
        # Emotion keywords
        emotions = {
            'Joy': ['happy', 'joy', 'excited', 'thrilled', 'love', 'great', 'wonderful', 'amazing', 'fantastic', 'ecstatic', 'delighted', 'elated', 'glad', 'pleased', 'cheerful', 'merry', 'blessed', 'grateful', 'content', 'satisfied'],
            'Sadness': ['sad', 'unhappy', 'depressed', 'down', 'upset', 'disappointed', 'grief', 'sorrow', 'mourning', 'heartbroken', 'devastated', 'miserable', 'hopeless', 'despair', 'lonely', 'empty', 'hurt', 'crying', 'tears', 'unfortunate'],
            'Anger': ['angry', 'mad', 'furious', 'annoyed', 'irritated', 'frustrated', 'outraged', 'enraged', 'hostile', 'bitter', 'resentful', 'hate', 'rage', 'livid', 'steaming', 'fuming', 'offended', 'infuriated'],
            'Fear': ['afraid', 'scared', 'fear', 'terrified', 'anxious', 'worried', 'nervous', 'panic', 'dread', 'horrified', 'frightened', 'alarmed', 'petrified', 'apprehensive', 'uneasy', 'tense', 'stressed', 'overwhelmed'],
            'Anxiety': ['anxious', 'worried', 'nervous', 'tense', 'stressed', 'overwhelmed', 'uneasy', 'restless', 'on edge', 'concerned', 'apprehensive', 'uncertain', 'doubtful', 'uneasy', 'jittery', 'edgy'],
            'Excitement': ['excited', 'thrilled', 'pumped', 'awesome', 'can\'t wait', 'amazing', 'incredible', 'fantastic', 'exhilarated', 'energized', 'enthusiastic', 'eager', 'motivated', 'inspired', 'fired up'],
            'Surprise': ['surprised', 'amazed', 'shocked', 'astonished', 'stunned', 'unexpected', 'wow', 'unbelievable', 'incredible', 'speechless', 'astonished', 'startled'],
            'Disgust': ['disgusted', 'revolted', 'repulsed', 'sickened', 'dislike', 'gross', 'nasty', 'awful', 'terrible', 'horrible', 'vile', 'sick', 'nauseous'],
            'Hope': ['hope', 'hopeful', 'optimistic', 'positive', 'looking forward', 'wish', 'pray', 'trust', 'believe', 'confident', 'expect', 'eager', 'anticipate'],
            'Gratitude': ['thank', 'grateful', 'appreciate', 'blessed', 'fortunate', 'lucky', 'thanks', 'appreciative', 'obliged', 'indebted']
        }
        
        # Detect primary emotions
        found_emotions = []
        emotion_scores = {}
        
        for emotion, keywords in emotions.items():
            score = 0
            for keyword in keywords:
                if keyword in text_lower:
                    score += 1
            if score > 0:
                emotion_scores[emotion] = score
        
        # Sort by score and return top emotions
        if emotion_scores:
            sorted_emotions = sorted(emotion_scores.items(), key=lambda x: x[1], reverse=True)
            # Return top 2 emotions if scores are significant
            if sorted_emotions[0][1] >= 2:
                found_emotions = [e[0] for e in sorted_emotions[:2]]
            else:
                found_emotions = [sorted_emotions[0][0]]
        
        if not found_emotions:
            found_emotions = ['Neutral']
        
        return ' + '.join(found_emotions)
    
    def encrypt(self, text):
        """Encrypt text and embed emotion signature"""
        # Detect emotion first
        emotion = self.detect_emotion(text)
        
        # Encrypt the text
        encrypted_bytes = self.cipher.encrypt(text.encode())
        encrypted_text = base64.urlsafe_b64encode(encrypted_bytes).decode()
        
        # Create emotion signature (hidden in the output)
        # We'll embed it as a prefix that can be extracted
        emotion_hash = self._emotion_to_signature(emotion)
        
        # Final output: signature + encrypted text
        final_output = f"{emotion_hash}::{encrypted_text}"
        
        return {
            'encrypted': final_output,
            'emotion': emotion,
            'key': self.key.decode()
        }
    
    def decrypt(self, encrypted_package):
        """Decrypt and extract emotion"""
        try:
            # Extract signature and encrypted text
            if '::' in encrypted_package:
                emotion_signature, encrypted_text = encrypted_package.split('::', 1)
                emotion = self._signature_to_emotion(emotion_signature)
            else:
                # Legacy format - just decrypt
                encrypted_text = encrypted_package
                emotion = 'Unknown'
            
            # Decrypt
            try:
                decrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
                original_text = self.cipher.decrypt(decrypted_bytes).decode()
            except:
                # Try with current key
                decrypted_bytes = self.cipher.decrypt(encrypted_text.encode())
                original_text = decrypted_bytes.decode()
            
            return {
                'original': original_text,
                'emotion': emotion
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _emotion_to_signature(self, emotion):
        """Convert emotion to a hidden signature"""
        # Simple encoding - convert emotion to numbers
        # This is the "hidden" part that AI would detect
        emotion_base = emotion.replace(' + ', '').upper()
        signature = ''
        for char in emotion_base:
            signature += str(ord(char) - 64)  # A=1, B=2, etc.
        return signature
    
    def _signature_to_emotion(self, signature):
        """Convert signature back to emotion"""
        # This is a simplified version
        # In production, you'd use a proper mapping
        emotions = {
            '1': 'Joy', '10': 'Sadness', '11': 'Anger', '12': 'Fear',
            '114': 'Anxiety', '524': 'Excitement', '1921': 'Surprise',
            '415': 'Disgust', '815': 'Hope', '7115': 'Gratitude'
        }
        return emotions.get(signature, 'Neutral')


# Test the cipher
if __name__ == "__main__":
    cipher = EmotionCipher()
    
    # Test 1
    text1 = "Feeling ecstatic about joining the new AI research team, though a bit anxious about the deadlines ahead."
    result1 = cipher.encrypt(text1)
    print(f"Original: {text1}")
    print(f"Encrypted: {result1['encrypted']}")
    print(f"Emotion: {result1['emotion']}")
    print()
    
    # Decrypt
    decrypted = cipher.decrypt(result1['encrypted'])
    print(f"Decrypted: {decrypted['original']}")
    print(f"Detected Emotion: {decrypted['emotion']}")
